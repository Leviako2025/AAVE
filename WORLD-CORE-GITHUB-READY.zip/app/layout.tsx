import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'WORLD-CORE — Transparent Advertising Marketplace',
  description: 'A professional advertising marketplace built around clear sponsorship, advertiser information and transparent destinations.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
