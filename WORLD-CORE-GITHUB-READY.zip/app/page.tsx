const categories = [
  ['◈','Gaming','Games, studios, esports & entertainment'],
  ['↗','Finance','Platforms, tools & financial products'],
  ['□','Products','Brands and products people can discover'],
  ['◎','Web & Apps','Digital products and online services'],
  ['✦','Creators','Creators, media & publishing'],
  ['+','Business','Companies ready to be discovered'],
];

const campaigns = [
  { name:'NOVA PLAY', type:'Gaming', status:'Verified advertiser', desc:'A featured gaming campaign with a clearly disclosed paid placement.', metric:'Sponsored discovery' },
  { name:'CORE MARKET', type:'Business', status:'Website reviewed', desc:'A business listing with destination details available before visiting.', metric:'Verified destination' },
  { name:'PIXEL LABS', type:'Products', status:'Paid promotion', desc:'A product campaign that identifies the advertiser and promotion type.', metric:'Sponsored placement' },
];

export default function Home() {
  return <main>
    <nav className="nav wrap">
      <a className="logo" href="#top" aria-label="WORLD-CORE home"><span>W</span> WORLD-CORE</a>
      <div className="links"><a href="#explore">Explore</a><a href="#transparency">Transparency</a><a href="#advertise">Advertise</a></div>
      <a className="navbtn" href="#advertise">Get Started</a>
    </nav>

    <section id="top" className="hero wrap">
      <div className="eyebrow">GLOBAL ADVERTISING MARKETPLACE</div>
      <h1>Where <em>brands</em><br/>meet attention.</h1>
      <p>Discover businesses, products, games and digital services through an advertising marketplace designed around clear sponsorship, advertiser information and transparent destinations.</p>
      <div className="actions"><a className="primary" href="#explore">Explore campaigns <b>→</b></a><a className="secondary" href="#advertise">Advertise with WORLD-CORE</a></div>
      <div className="search"><span>⌕</span><input aria-label="Search" placeholder="Search brands, products, apps, games…"/><kbd>⌘ K</kbd></div>
      <div className="trustbar"><span>✓ Sponsored content is labeled</span><span>✓ Advertiser information is visible</span><span>✓ Report questionable ads</span></div>
    </section>

    <section id="explore" className="section wrap">
      <div className="sectionhead"><div><div className="eyebrow">DISCOVER</div><h2>Explore the marketplace</h2></div><span className="muted">Built for clear discovery.</span></div>
      <div className="grid cats">{categories.map(([icon,name,desc])=><a className="card cat" href="#campaigns" key={name}><div className="icon">{icon}</div><h3>{name}</h3><p>{desc}</p><span>Explore →</span></a>)}</div>
    </section>

    <section id="campaigns" className="section dark">
      <div className="wrap">
        <div className="sectionhead"><div><div className="eyebrow">SPONSORED DISCOVERY</div><h2>Featured campaigns</h2></div><span className="muted">Paid placements are clearly labeled.</span></div>
        <div className="grid featured">{campaigns.map((x,i)=><article className="feature" key={x.name}>
          <div className={'featureart art'+i}><span>{i===0?'NOVA':i===1?'CORE':'PIXEL'}</span><i>ADVERTISEMENT</i></div>
          <div className="featurebody"><div className="badges"><span>Sponsored</span><small>{x.status}</small></div><h3>{x.name}</h3><p>{x.desc}</p><div className="featuremeta"><small>{x.type}</small><small>{x.metric}</small></div><a href="#transparency">View transparency →</a></div>
        </article>)}</div>
      </div>
    </section>

    <section id="transparency" className="trust wrap">
      <div className="trustcopy"><div className="eyebrow">AD TRANSPARENCY</div><h2>Trust should be <em>visible.</em></h2><p>Every campaign should tell people when it is paid promotion, who the advertiser is, where the ad leads, and what verification has actually been completed.</p><a className="primary" href="#advertise">See advertising standards →</a></div>
      <div className="checks">
        <div><b>✓</b><span><strong>Sponsored label</strong><small>Paid placements are identified clearly.</small></span></div>
        <div><b>✓</b><span><strong>Advertiser identity</strong><small>Business information can be reviewed.</small></span></div>
        <div><b>✓</b><span><strong>Destination visibility</strong><small>Users can see where an ad leads.</small></span></div>
        <div><b>✓</b><span><strong>Report an ad</strong><small>Questionable campaigns can be flagged.</small></span></div>
      </div>
    </section>

    <section id="advertise" className="cta wrap">
      <div><div className="eyebrow">FOR ADVERTISERS</div><h2>Make your campaign<br/><em>easy to understand.</em></h2><p>Show your brand to the right audience with clear campaign information, transparent sponsorship labels and a professional destination.</p></div>
      <div className="ctaBtns"><a className="primary" href="#contact">Start an advertising request →</a><a className="secondary" href="#transparency">Read our standards</a></div>
    </section>

    <section id="contact" className="contact wrap"><div><div className="eyebrow">CONTACT</div><h2>Ready to advertise?</h2><p>Campaign submission, verification and payment features can be connected here as the marketplace backend is added.</p></div><div className="contactcard"><strong>Advertiser onboarding</strong><span>Campaign details • Business details • Destination URL</span><small>Payments and verification are handled only through the official WORLD-CORE platform when enabled.</small></div></section>

    <footer className="footer wrap"><div><div className="logo"><span>W</span> WORLD-CORE</div><p>Where brands meet attention — with transparency.</p></div><div className="footlinks"><a href="#transparency">Transparency</a><a href="#advertise">Advertise</a><a href="#contact">Contact</a><a href="#">Privacy</a><a href="#">Terms</a></div><small>© 2026 WORLD-CORE. Paid advertising is not endorsement. Verification describes checks completed, not a guarantee of performance or outcome.</small></footer>
  </main>;
}
