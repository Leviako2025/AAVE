# WORLD-CORE

A Next.js advertising marketplace focused on professional presentation, clear sponsorship labels and advertising transparency.

## Run locally
npm install
npm run dev

## Deploy to Vercel
Import this folder as the project root. The `package.json` and `app/` directory must be at the repository root.

## Important
This version is a frontend foundation. Advertiser accounts, campaign payments, verification workflows, analytics, reporting and database-backed submissions should be added server-side before accepting real advertising payments or claiming verification.
